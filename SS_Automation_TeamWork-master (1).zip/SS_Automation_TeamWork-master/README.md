# Team project based on Advanced Page Object Model contains Tests for OpenCart eCommerce platform.

Project is using C# Programming language - target Framework: .NET Framework 4.5

Additional drivers: <Selenium.WebDriver v3.141.0 | Selenium.Webdriver.ChromeDriver v73.0.3683.68>

<MSTest.TestAdapter v1.4.0 | MSTest.Testframework v1.4.0>



Used tools:

Visual Studio Community 2017 | Integrated Development Environment

Sourcetree | Git GUI tool

Google Chrome | Browser

Skype | Team communicating tool

Google Sheets | Planning tool
