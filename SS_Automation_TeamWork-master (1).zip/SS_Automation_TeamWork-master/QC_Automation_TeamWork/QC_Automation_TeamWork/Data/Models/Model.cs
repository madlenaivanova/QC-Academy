﻿
namespace QC_Automation_TeamWork.Data.Models
{
    public class Model
    {
        public Model(string modelname)
        {
            Modelname = modelname;
        }

        public string Modelname { get; set; }
    }
}
