﻿using QC_Automation_TeamWork.Core;

namespace QC_Automation_TeamWork.Pages
{
    public class HeaderValidator : BasePageValidator<HeaderElementMap>
    {
    }
}
