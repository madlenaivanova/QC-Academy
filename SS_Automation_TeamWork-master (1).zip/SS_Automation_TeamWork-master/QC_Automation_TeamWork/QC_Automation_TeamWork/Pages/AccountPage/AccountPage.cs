﻿using QC_Automation_TeamWork.Core;

namespace QC_Automation_TeamWork.Pages
{
    public class AccountPage : BasePage<AccountPageElementMap, AccountPageValidator>
    {

    }
}
