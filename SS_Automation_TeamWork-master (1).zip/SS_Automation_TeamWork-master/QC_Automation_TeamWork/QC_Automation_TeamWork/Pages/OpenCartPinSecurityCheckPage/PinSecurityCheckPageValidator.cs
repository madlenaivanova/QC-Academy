﻿using QC_Automation_TeamWork.Core;

namespace QC_Automation_TeamWork.Pages
{
    public class PinSecurityCheckPageValidator : BasePageValidator<PinSecurityCheckPageElementMap>
    {
    }
}