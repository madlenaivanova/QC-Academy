﻿using QC_Automation_TeamWork.Core;

namespace QC_Automation_TeamWork.Pages
{
    public class StoreSuccessContactPage : BasePage<StoreSuccessContactPageElementMap, StoreSuccessContactPageValidator>
    {

    }
}
